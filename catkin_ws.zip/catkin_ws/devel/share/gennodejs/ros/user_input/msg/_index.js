
"use strict";

let UserInput = require('./UserInput.js');

module.exports = {
  UserInput: UserInput,
};
