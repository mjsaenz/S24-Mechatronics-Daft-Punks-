// Auto-generated. Do not edit!

// (in-package floor_contact_feedback.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class LegStates {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.leg1_state = null;
      this.leg2_state = null;
      this.leg3_state = null;
      this.leg4_state = null;
      this.leg5_state = null;
      this.leg6_state = null;
    }
    else {
      if (initObj.hasOwnProperty('leg1_state')) {
        this.leg1_state = initObj.leg1_state
      }
      else {
        this.leg1_state = false;
      }
      if (initObj.hasOwnProperty('leg2_state')) {
        this.leg2_state = initObj.leg2_state
      }
      else {
        this.leg2_state = false;
      }
      if (initObj.hasOwnProperty('leg3_state')) {
        this.leg3_state = initObj.leg3_state
      }
      else {
        this.leg3_state = false;
      }
      if (initObj.hasOwnProperty('leg4_state')) {
        this.leg4_state = initObj.leg4_state
      }
      else {
        this.leg4_state = false;
      }
      if (initObj.hasOwnProperty('leg5_state')) {
        this.leg5_state = initObj.leg5_state
      }
      else {
        this.leg5_state = false;
      }
      if (initObj.hasOwnProperty('leg6_state')) {
        this.leg6_state = initObj.leg6_state
      }
      else {
        this.leg6_state = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LegStates
    // Serialize message field [leg1_state]
    bufferOffset = _serializer.bool(obj.leg1_state, buffer, bufferOffset);
    // Serialize message field [leg2_state]
    bufferOffset = _serializer.bool(obj.leg2_state, buffer, bufferOffset);
    // Serialize message field [leg3_state]
    bufferOffset = _serializer.bool(obj.leg3_state, buffer, bufferOffset);
    // Serialize message field [leg4_state]
    bufferOffset = _serializer.bool(obj.leg4_state, buffer, bufferOffset);
    // Serialize message field [leg5_state]
    bufferOffset = _serializer.bool(obj.leg5_state, buffer, bufferOffset);
    // Serialize message field [leg6_state]
    bufferOffset = _serializer.bool(obj.leg6_state, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LegStates
    let len;
    let data = new LegStates(null);
    // Deserialize message field [leg1_state]
    data.leg1_state = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [leg2_state]
    data.leg2_state = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [leg3_state]
    data.leg3_state = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [leg4_state]
    data.leg4_state = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [leg5_state]
    data.leg5_state = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [leg6_state]
    data.leg6_state = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 6;
  }

  static datatype() {
    // Returns string type for a message object
    return 'floor_contact_feedback/LegStates';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b3dae4bbb110ea3165645aa0b208d88c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool leg1_state
    bool leg2_state
    bool leg3_state
    bool leg4_state
    bool leg5_state
    bool leg6_state
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LegStates(null);
    if (msg.leg1_state !== undefined) {
      resolved.leg1_state = msg.leg1_state;
    }
    else {
      resolved.leg1_state = false
    }

    if (msg.leg2_state !== undefined) {
      resolved.leg2_state = msg.leg2_state;
    }
    else {
      resolved.leg2_state = false
    }

    if (msg.leg3_state !== undefined) {
      resolved.leg3_state = msg.leg3_state;
    }
    else {
      resolved.leg3_state = false
    }

    if (msg.leg4_state !== undefined) {
      resolved.leg4_state = msg.leg4_state;
    }
    else {
      resolved.leg4_state = false
    }

    if (msg.leg5_state !== undefined) {
      resolved.leg5_state = msg.leg5_state;
    }
    else {
      resolved.leg5_state = false
    }

    if (msg.leg6_state !== undefined) {
      resolved.leg6_state = msg.leg6_state;
    }
    else {
      resolved.leg6_state = false
    }

    return resolved;
    }
};

module.exports = LegStates;
