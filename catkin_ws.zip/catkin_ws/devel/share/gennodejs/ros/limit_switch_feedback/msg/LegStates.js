// Auto-generated. Do not edit!

// (in-package limit_switch_feedback.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class LegStates {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.foot1 = null;
      this.foot2 = null;
      this.foot3 = null;
      this.foot4 = null;
      this.foot5 = null;
      this.foot6 = null;
      this.forward1 = null;
      this.forward2 = null;
      this.forward3 = null;
      this.forward4 = null;
      this.forward5 = null;
      this.forward6 = null;
      this.backwards1 = null;
      this.backwards2 = null;
      this.backwards3 = null;
      this.backwards4 = null;
      this.backwards5 = null;
      this.backwards6 = null;
    }
    else {
      if (initObj.hasOwnProperty('foot1')) {
        this.foot1 = initObj.foot1
      }
      else {
        this.foot1 = false;
      }
      if (initObj.hasOwnProperty('foot2')) {
        this.foot2 = initObj.foot2
      }
      else {
        this.foot2 = false;
      }
      if (initObj.hasOwnProperty('foot3')) {
        this.foot3 = initObj.foot3
      }
      else {
        this.foot3 = false;
      }
      if (initObj.hasOwnProperty('foot4')) {
        this.foot4 = initObj.foot4
      }
      else {
        this.foot4 = false;
      }
      if (initObj.hasOwnProperty('foot5')) {
        this.foot5 = initObj.foot5
      }
      else {
        this.foot5 = false;
      }
      if (initObj.hasOwnProperty('foot6')) {
        this.foot6 = initObj.foot6
      }
      else {
        this.foot6 = false;
      }
      if (initObj.hasOwnProperty('forward1')) {
        this.forward1 = initObj.forward1
      }
      else {
        this.forward1 = false;
      }
      if (initObj.hasOwnProperty('forward2')) {
        this.forward2 = initObj.forward2
      }
      else {
        this.forward2 = false;
      }
      if (initObj.hasOwnProperty('forward3')) {
        this.forward3 = initObj.forward3
      }
      else {
        this.forward3 = false;
      }
      if (initObj.hasOwnProperty('forward4')) {
        this.forward4 = initObj.forward4
      }
      else {
        this.forward4 = false;
      }
      if (initObj.hasOwnProperty('forward5')) {
        this.forward5 = initObj.forward5
      }
      else {
        this.forward5 = false;
      }
      if (initObj.hasOwnProperty('forward6')) {
        this.forward6 = initObj.forward6
      }
      else {
        this.forward6 = false;
      }
      if (initObj.hasOwnProperty('backwards1')) {
        this.backwards1 = initObj.backwards1
      }
      else {
        this.backwards1 = false;
      }
      if (initObj.hasOwnProperty('backwards2')) {
        this.backwards2 = initObj.backwards2
      }
      else {
        this.backwards2 = false;
      }
      if (initObj.hasOwnProperty('backwards3')) {
        this.backwards3 = initObj.backwards3
      }
      else {
        this.backwards3 = false;
      }
      if (initObj.hasOwnProperty('backwards4')) {
        this.backwards4 = initObj.backwards4
      }
      else {
        this.backwards4 = false;
      }
      if (initObj.hasOwnProperty('backwards5')) {
        this.backwards5 = initObj.backwards5
      }
      else {
        this.backwards5 = false;
      }
      if (initObj.hasOwnProperty('backwards6')) {
        this.backwards6 = initObj.backwards6
      }
      else {
        this.backwards6 = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LegStates
    // Serialize message field [foot1]
    bufferOffset = _serializer.bool(obj.foot1, buffer, bufferOffset);
    // Serialize message field [foot2]
    bufferOffset = _serializer.bool(obj.foot2, buffer, bufferOffset);
    // Serialize message field [foot3]
    bufferOffset = _serializer.bool(obj.foot3, buffer, bufferOffset);
    // Serialize message field [foot4]
    bufferOffset = _serializer.bool(obj.foot4, buffer, bufferOffset);
    // Serialize message field [foot5]
    bufferOffset = _serializer.bool(obj.foot5, buffer, bufferOffset);
    // Serialize message field [foot6]
    bufferOffset = _serializer.bool(obj.foot6, buffer, bufferOffset);
    // Serialize message field [forward1]
    bufferOffset = _serializer.bool(obj.forward1, buffer, bufferOffset);
    // Serialize message field [forward2]
    bufferOffset = _serializer.bool(obj.forward2, buffer, bufferOffset);
    // Serialize message field [forward3]
    bufferOffset = _serializer.bool(obj.forward3, buffer, bufferOffset);
    // Serialize message field [forward4]
    bufferOffset = _serializer.bool(obj.forward4, buffer, bufferOffset);
    // Serialize message field [forward5]
    bufferOffset = _serializer.bool(obj.forward5, buffer, bufferOffset);
    // Serialize message field [forward6]
    bufferOffset = _serializer.bool(obj.forward6, buffer, bufferOffset);
    // Serialize message field [backwards1]
    bufferOffset = _serializer.bool(obj.backwards1, buffer, bufferOffset);
    // Serialize message field [backwards2]
    bufferOffset = _serializer.bool(obj.backwards2, buffer, bufferOffset);
    // Serialize message field [backwards3]
    bufferOffset = _serializer.bool(obj.backwards3, buffer, bufferOffset);
    // Serialize message field [backwards4]
    bufferOffset = _serializer.bool(obj.backwards4, buffer, bufferOffset);
    // Serialize message field [backwards5]
    bufferOffset = _serializer.bool(obj.backwards5, buffer, bufferOffset);
    // Serialize message field [backwards6]
    bufferOffset = _serializer.bool(obj.backwards6, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LegStates
    let len;
    let data = new LegStates(null);
    // Deserialize message field [foot1]
    data.foot1 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [foot2]
    data.foot2 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [foot3]
    data.foot3 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [foot4]
    data.foot4 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [foot5]
    data.foot5 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [foot6]
    data.foot6 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [forward1]
    data.forward1 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [forward2]
    data.forward2 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [forward3]
    data.forward3 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [forward4]
    data.forward4 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [forward5]
    data.forward5 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [forward6]
    data.forward6 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [backwards1]
    data.backwards1 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [backwards2]
    data.backwards2 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [backwards3]
    data.backwards3 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [backwards4]
    data.backwards4 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [backwards5]
    data.backwards5 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [backwards6]
    data.backwards6 = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 18;
  }

  static datatype() {
    // Returns string type for a message object
    return 'limit_switch_feedback/LegStates';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '527c98c220ed1e5fa0c3875a325223f7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool foot1
    bool foot2
    bool foot3
    bool foot4
    bool foot5
    bool foot6
    bool forward1
    bool forward2
    bool forward3
    bool forward4
    bool forward5
    bool forward6
    bool backwards1
    bool backwards2
    bool backwards3
    bool backwards4
    bool backwards5
    bool backwards6
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LegStates(null);
    if (msg.foot1 !== undefined) {
      resolved.foot1 = msg.foot1;
    }
    else {
      resolved.foot1 = false
    }

    if (msg.foot2 !== undefined) {
      resolved.foot2 = msg.foot2;
    }
    else {
      resolved.foot2 = false
    }

    if (msg.foot3 !== undefined) {
      resolved.foot3 = msg.foot3;
    }
    else {
      resolved.foot3 = false
    }

    if (msg.foot4 !== undefined) {
      resolved.foot4 = msg.foot4;
    }
    else {
      resolved.foot4 = false
    }

    if (msg.foot5 !== undefined) {
      resolved.foot5 = msg.foot5;
    }
    else {
      resolved.foot5 = false
    }

    if (msg.foot6 !== undefined) {
      resolved.foot6 = msg.foot6;
    }
    else {
      resolved.foot6 = false
    }

    if (msg.forward1 !== undefined) {
      resolved.forward1 = msg.forward1;
    }
    else {
      resolved.forward1 = false
    }

    if (msg.forward2 !== undefined) {
      resolved.forward2 = msg.forward2;
    }
    else {
      resolved.forward2 = false
    }

    if (msg.forward3 !== undefined) {
      resolved.forward3 = msg.forward3;
    }
    else {
      resolved.forward3 = false
    }

    if (msg.forward4 !== undefined) {
      resolved.forward4 = msg.forward4;
    }
    else {
      resolved.forward4 = false
    }

    if (msg.forward5 !== undefined) {
      resolved.forward5 = msg.forward5;
    }
    else {
      resolved.forward5 = false
    }

    if (msg.forward6 !== undefined) {
      resolved.forward6 = msg.forward6;
    }
    else {
      resolved.forward6 = false
    }

    if (msg.backwards1 !== undefined) {
      resolved.backwards1 = msg.backwards1;
    }
    else {
      resolved.backwards1 = false
    }

    if (msg.backwards2 !== undefined) {
      resolved.backwards2 = msg.backwards2;
    }
    else {
      resolved.backwards2 = false
    }

    if (msg.backwards3 !== undefined) {
      resolved.backwards3 = msg.backwards3;
    }
    else {
      resolved.backwards3 = false
    }

    if (msg.backwards4 !== undefined) {
      resolved.backwards4 = msg.backwards4;
    }
    else {
      resolved.backwards4 = false
    }

    if (msg.backwards5 !== undefined) {
      resolved.backwards5 = msg.backwards5;
    }
    else {
      resolved.backwards5 = false
    }

    if (msg.backwards6 !== undefined) {
      resolved.backwards6 = msg.backwards6;
    }
    else {
      resolved.backwards6 = false
    }

    return resolved;
    }
};

module.exports = LegStates;
