// Auto-generated. Do not edit!

// (in-package limit_switch_feedback.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class LimitSwitchStates {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.foot1 = null;
      this.foot2 = null;
      this.foot3 = null;
      this.foot4 = null;
      this.foot5 = null;
      this.foot6 = null;
    }
    else {
      if (initObj.hasOwnProperty('foot1')) {
        this.foot1 = initObj.foot1
      }
      else {
        this.foot1 = false;
      }
      if (initObj.hasOwnProperty('foot2')) {
        this.foot2 = initObj.foot2
      }
      else {
        this.foot2 = false;
      }
      if (initObj.hasOwnProperty('foot3')) {
        this.foot3 = initObj.foot3
      }
      else {
        this.foot3 = false;
      }
      if (initObj.hasOwnProperty('foot4')) {
        this.foot4 = initObj.foot4
      }
      else {
        this.foot4 = false;
      }
      if (initObj.hasOwnProperty('foot5')) {
        this.foot5 = initObj.foot5
      }
      else {
        this.foot5 = false;
      }
      if (initObj.hasOwnProperty('foot6')) {
        this.foot6 = initObj.foot6
      }
      else {
        this.foot6 = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LimitSwitchStates
    // Serialize message field [foot1]
    bufferOffset = _serializer.bool(obj.foot1, buffer, bufferOffset);
    // Serialize message field [foot2]
    bufferOffset = _serializer.bool(obj.foot2, buffer, bufferOffset);
    // Serialize message field [foot3]
    bufferOffset = _serializer.bool(obj.foot3, buffer, bufferOffset);
    // Serialize message field [foot4]
    bufferOffset = _serializer.bool(obj.foot4, buffer, bufferOffset);
    // Serialize message field [foot5]
    bufferOffset = _serializer.bool(obj.foot5, buffer, bufferOffset);
    // Serialize message field [foot6]
    bufferOffset = _serializer.bool(obj.foot6, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LimitSwitchStates
    let len;
    let data = new LimitSwitchStates(null);
    // Deserialize message field [foot1]
    data.foot1 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [foot2]
    data.foot2 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [foot3]
    data.foot3 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [foot4]
    data.foot4 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [foot5]
    data.foot5 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [foot6]
    data.foot6 = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 6;
  }

  static datatype() {
    // Returns string type for a message object
    return 'limit_switch_feedback/LimitSwitchStates';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '538ef3e7dd21e6dd0d26b96e492a3911';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool foot1
    bool foot2
    bool foot3
    bool foot4
    bool foot5
    bool foot6
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LimitSwitchStates(null);
    if (msg.foot1 !== undefined) {
      resolved.foot1 = msg.foot1;
    }
    else {
      resolved.foot1 = false
    }

    if (msg.foot2 !== undefined) {
      resolved.foot2 = msg.foot2;
    }
    else {
      resolved.foot2 = false
    }

    if (msg.foot3 !== undefined) {
      resolved.foot3 = msg.foot3;
    }
    else {
      resolved.foot3 = false
    }

    if (msg.foot4 !== undefined) {
      resolved.foot4 = msg.foot4;
    }
    else {
      resolved.foot4 = false
    }

    if (msg.foot5 !== undefined) {
      resolved.foot5 = msg.foot5;
    }
    else {
      resolved.foot5 = false
    }

    if (msg.foot6 !== undefined) {
      resolved.foot6 = msg.foot6;
    }
    else {
      resolved.foot6 = false
    }

    return resolved;
    }
};

module.exports = LimitSwitchStates;
