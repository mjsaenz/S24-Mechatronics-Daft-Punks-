// Auto-generated. Do not edit!

// (in-package locomotion_algorithm.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class MotorCommands {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.s1 = null;
      this.s2 = null;
      this.s3 = null;
      this.s4 = null;
      this.s5 = null;
      this.s6 = null;
      this.l1 = null;
      this.l2 = null;
      this.l3 = null;
      this.l4 = null;
      this.l5 = null;
      this.l6 = null;
    }
    else {
      if (initObj.hasOwnProperty('s1')) {
        this.s1 = initObj.s1
      }
      else {
        this.s1 = '';
      }
      if (initObj.hasOwnProperty('s2')) {
        this.s2 = initObj.s2
      }
      else {
        this.s2 = '';
      }
      if (initObj.hasOwnProperty('s3')) {
        this.s3 = initObj.s3
      }
      else {
        this.s3 = '';
      }
      if (initObj.hasOwnProperty('s4')) {
        this.s4 = initObj.s4
      }
      else {
        this.s4 = '';
      }
      if (initObj.hasOwnProperty('s5')) {
        this.s5 = initObj.s5
      }
      else {
        this.s5 = '';
      }
      if (initObj.hasOwnProperty('s6')) {
        this.s6 = initObj.s6
      }
      else {
        this.s6 = '';
      }
      if (initObj.hasOwnProperty('l1')) {
        this.l1 = initObj.l1
      }
      else {
        this.l1 = '';
      }
      if (initObj.hasOwnProperty('l2')) {
        this.l2 = initObj.l2
      }
      else {
        this.l2 = '';
      }
      if (initObj.hasOwnProperty('l3')) {
        this.l3 = initObj.l3
      }
      else {
        this.l3 = '';
      }
      if (initObj.hasOwnProperty('l4')) {
        this.l4 = initObj.l4
      }
      else {
        this.l4 = '';
      }
      if (initObj.hasOwnProperty('l5')) {
        this.l5 = initObj.l5
      }
      else {
        this.l5 = '';
      }
      if (initObj.hasOwnProperty('l6')) {
        this.l6 = initObj.l6
      }
      else {
        this.l6 = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MotorCommands
    // Serialize message field [s1]
    bufferOffset = _serializer.string(obj.s1, buffer, bufferOffset);
    // Serialize message field [s2]
    bufferOffset = _serializer.string(obj.s2, buffer, bufferOffset);
    // Serialize message field [s3]
    bufferOffset = _serializer.string(obj.s3, buffer, bufferOffset);
    // Serialize message field [s4]
    bufferOffset = _serializer.string(obj.s4, buffer, bufferOffset);
    // Serialize message field [s5]
    bufferOffset = _serializer.string(obj.s5, buffer, bufferOffset);
    // Serialize message field [s6]
    bufferOffset = _serializer.string(obj.s6, buffer, bufferOffset);
    // Serialize message field [l1]
    bufferOffset = _serializer.string(obj.l1, buffer, bufferOffset);
    // Serialize message field [l2]
    bufferOffset = _serializer.string(obj.l2, buffer, bufferOffset);
    // Serialize message field [l3]
    bufferOffset = _serializer.string(obj.l3, buffer, bufferOffset);
    // Serialize message field [l4]
    bufferOffset = _serializer.string(obj.l4, buffer, bufferOffset);
    // Serialize message field [l5]
    bufferOffset = _serializer.string(obj.l5, buffer, bufferOffset);
    // Serialize message field [l6]
    bufferOffset = _serializer.string(obj.l6, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MotorCommands
    let len;
    let data = new MotorCommands(null);
    // Deserialize message field [s1]
    data.s1 = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [s2]
    data.s2 = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [s3]
    data.s3 = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [s4]
    data.s4 = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [s5]
    data.s5 = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [s6]
    data.s6 = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [l1]
    data.l1 = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [l2]
    data.l2 = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [l3]
    data.l3 = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [l4]
    data.l4 = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [l5]
    data.l5 = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [l6]
    data.l6 = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.s1);
    length += _getByteLength(object.s2);
    length += _getByteLength(object.s3);
    length += _getByteLength(object.s4);
    length += _getByteLength(object.s5);
    length += _getByteLength(object.s6);
    length += _getByteLength(object.l1);
    length += _getByteLength(object.l2);
    length += _getByteLength(object.l3);
    length += _getByteLength(object.l4);
    length += _getByteLength(object.l5);
    length += _getByteLength(object.l6);
    return length + 48;
  }

  static datatype() {
    // Returns string type for a message object
    return 'locomotion_algorithm/MotorCommands';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '47844904ec1e39129713dab86076dc57';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string s1
    string s2
    string s3
    string s4
    string s5
    string s6
    string l1
    string l2
    string l3
    string l4
    string l5
    string l6
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MotorCommands(null);
    if (msg.s1 !== undefined) {
      resolved.s1 = msg.s1;
    }
    else {
      resolved.s1 = ''
    }

    if (msg.s2 !== undefined) {
      resolved.s2 = msg.s2;
    }
    else {
      resolved.s2 = ''
    }

    if (msg.s3 !== undefined) {
      resolved.s3 = msg.s3;
    }
    else {
      resolved.s3 = ''
    }

    if (msg.s4 !== undefined) {
      resolved.s4 = msg.s4;
    }
    else {
      resolved.s4 = ''
    }

    if (msg.s5 !== undefined) {
      resolved.s5 = msg.s5;
    }
    else {
      resolved.s5 = ''
    }

    if (msg.s6 !== undefined) {
      resolved.s6 = msg.s6;
    }
    else {
      resolved.s6 = ''
    }

    if (msg.l1 !== undefined) {
      resolved.l1 = msg.l1;
    }
    else {
      resolved.l1 = ''
    }

    if (msg.l2 !== undefined) {
      resolved.l2 = msg.l2;
    }
    else {
      resolved.l2 = ''
    }

    if (msg.l3 !== undefined) {
      resolved.l3 = msg.l3;
    }
    else {
      resolved.l3 = ''
    }

    if (msg.l4 !== undefined) {
      resolved.l4 = msg.l4;
    }
    else {
      resolved.l4 = ''
    }

    if (msg.l5 !== undefined) {
      resolved.l5 = msg.l5;
    }
    else {
      resolved.l5 = ''
    }

    if (msg.l6 !== undefined) {
      resolved.l6 = msg.l6;
    }
    else {
      resolved.l6 = ''
    }

    return resolved;
    }
};

module.exports = MotorCommands;
