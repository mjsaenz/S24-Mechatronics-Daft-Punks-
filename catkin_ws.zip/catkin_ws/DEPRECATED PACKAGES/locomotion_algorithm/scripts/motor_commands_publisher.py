#!/usr/bin/env python3
import rospy
import time
import message_filters
from limit_switch_feedback.msg import LimitSwitchStates
from user_input.msg import UserInput

from locomotion_algorithm.msg import MotorCommands

state = 0 #0 = begin, 1 = extend, 2 = joint rotate forward, 3 = retract, 4 = joint rotate backwards

pub = None

def callback(limit_switch_data, user_input):
  global state
  global pub
  
  command = MotorCommands()

  command.l1 = "none"
  command.l2 = "none"
  command.l3 = "none"
  command.l4 = "none"
  command.l5 = "none"
  command.l6 = "none"
  command.s1 = "none"
  command.s2 = "none"
  command.s3 = "none"
  command.s4 = "none"
  command.s5 = "none"
  command.s6 = "none"

  foot1 = limit_switch_data.foot1
  if user_input.dir == "forward":
    if state == 0:
      if foot1:
        rospy.loginfo("Beginning leg extension")
        state = 1
        command.l1 = "extend"
        command.l2 = "extend"
        command.l3 = "extend"
        command.l4 = "extend"
        command.l5 = "extend"
        command.l6 = "extend"
    elif state == 1:
      if foot1:
        command.l1 = "extend"
        command.l2 = "extend"
        command.l3 = "extend"
        command.l4 = "extend"
        command.l5 = "extend"
        command.l6 = "extend"
      else:
        state = 2
        rospy.loginfo("No longer in contact with floor, beginning forward rotation")
        if user_input.speed == 0.5:
          command.s1 = "slow forward"
          command.s2 = "slow forward"
          command.s3 = "slow forward"
          command.s4 = "slow forward"
          command.s5 = "slow forward"
          command.s6 = "slow forward"
        else:
          command.s1 = "forward"
          command.s2 = "forward"
          command.s3 = "forward"
          command.s4 = "forward"
          command.s5 = "forward"
          command.s6 = "forward"
    elif state == 2:
      state = 3
      rospy.loginfo("forward rotation complete")
      command.l1 = "retract"
      command.l2 = "retract"
      command.l3 = "retract"
      command.l4 = "retract"
      command.l5 = "retract"
      command.l6 = "retract"
    elif state == 3:
      if not foot1:
        command.l1 = "retract"
        command.l2 = "retract"
        command.l3 = "retract"
        command.l4 = "retract"
        command.l5 = "retract"
        command.l6 = "retract"
      else:
        state = 4
        rospy.loginfo("In contact with floor, beginning backwards rotation")
        if user_input.speed == 0.5:
          command.s1 = "slow backwards"
          command.s2 = "slow backwards"
          command.s3 = "slow backwards"
          command.s4 = "slow backwards"
          command.s5 = "slow backwards"
          command.s6 = "slow backwards"
        else:
          command.s1 = "backwards"
          command.s2 = "backwards"
          command.s3 = "backwards"
          command.s4 = "backwards"
          command.s5 = "backwards"
          command.s6 = "backwards"

    else:
      state = 1
      rospy.loginfo("Backwards rotation complete")
      command.l1 = "extend"
      command.l2 = "extend"
      command.l3 = "extend"
      command.l4 = "extend"
      command.l5 = "extend"
      command.l6 = "extend"
  elif user_input.dir == "backwards":
    if state == 0:
      if foot1:
        rospy.loginfo("Beginning leg extension")
        state = 1
        command.l1 = "extend"
        command.l2 = "extend"
        command.l3 = "extend"
        command.l4 = "extend"
        command.l5 = "extend"
        command.l6 = "extend"
    elif state == 1:
      if foot1:
        command.l1 = "extend"
        command.l2 = "extend"
        command.l3 = "extend"
        command.l4 = "extend"
        command.l5 = "extend"
        command.l6 = "extend"
      else:
        state = 4
        rospy.loginfo("No longer in contact with floor, beginning backwards rotation")
        if user_input.speed == 0.5:
          command.s1 = "slow backwards"
          command.s2 = "slow backwards"
          command.s3 = "slow backwards"
          command.s4 = "slow backwards"
          command.s5 = "slow backwards"
          command.s6 = "slow backwards"
        else:
          command.s1 = "backwards"
          command.s2 = "backwards"
          command.s3 = "backwards"
          command.s4 = "backwards"
          command.s5 = "backwards"
          command.s6 = "backwards"
    elif state == 2:
      state = 1
      rospy.loginfo("forward rotation complete")
      command.l1 = "extend"
      command.l2 = "extend"
      command.l3 = "extend"
      command.l4 = "extend"
      command.l5 = "extend"
      command.l6 = "extend"
    elif state == 3:
      if not foot1:
        command.l1 = "retract"
        command.l2 = "retract"
        command.l3 = "retract"
        command.l4 = "retract"
        command.l5 = "retract"
        command.l6 = "retract"
      else:
        state = 2
        rospy.loginfo("In contact with floor, beginning forwards rotation")
        if user_input.speed == 0.5:
          command.s1 = "slow forward"
          command.s2 = "slow forward"
          command.s3 = "slow forward"
          command.s4 = "slow forward"
          command.s5 = "slow forward"
          command.s6 = "slow forward"
        else:
          command.s1 = "forward"
          command.s2 = "forward"
          command.s3 = "forward"
          command.s4 = "forward"
          command.s5 = "forward"
          command.s6 = "forward"
    else:
      state = 3
      rospy.loginfo("Backwards rotation complete")
      command.l1 = "retract"
      command.l2 = "retract"
      command.l3 = "retract"
      command.l4 = "retract"
      command.l5 = "retract"
      command.l6 = "retract"
  else:
    if not foot1:
      command.l1 = "retract"
      command.l2 = "retract"
      command.l3 = "retract"
      command.l4 = "retract"
      command.l5 = "retract"
      command.l6 = "retract"
      
  pub.publish(command)
  #rospy.loginfo(state_string)

def start():
  rospy.init_node('locomotion_algorithm', anonymous=True)
  global pub
  
  pub = rospy.Publisher('motor_command_pub', MotorCommands, queue_size=1) 

  #ser = serial.Serial('/dev/ttyACM0', 9600);
  limit_switch_sub = message_filters.Subscriber('limit_switch_states_pub', LimitSwitchStates)
  user_input_sub = message_filters.Subscriber('user_input_pub', UserInput)

  ts = message_filters.ApproximateTimeSynchronizer([limit_switch_sub, user_input_sub], 10, 0.1, allow_headerless=True)
  ts.registerCallback(callback)
  rospy.spin()

if __name__ == '__main__':
  start()
