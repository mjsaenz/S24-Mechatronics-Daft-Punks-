#!/usr/bin/env python3
import rospy
import RPi.GPIO as GPIO
from limit_switch_feedback.msg import LimitSwitchStates

out_pin = 7
foot_1 = 11
foot_2 = 12
foot_3 = 13
foot_4 = 15
foot_5 = 16
foot_6 = 18

def pub_leg_state():
  pub = rospy.Publisher('limit_switch_states_pub', LimitSwitchStates)
  rospy.init_node('limit_switch_states_publisher', anonymous=True)
  r = rospy.Rate(10)
  msg = LimitSwitchStates()
  
  GPIO.setmode(GPIO.BOARD)
  GPIO.setup(out_pin, GPIO.OUT)
  # foot limit switches
  GPIO.setup(foot_1, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
  GPIO.setup(foot_2, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
  GPIO.setup(foot_3, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
  GPIO.setup(foot_4, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
  GPIO.setup(foot_5, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
  GPIO.setup(foot_6, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

  GPIO.output(out_pin, True)

  while not rospy.is_shutdown():
    msg.foot1 = not GPIO.input(foot_1)
    msg.foot2 = not GPIO.input(foot_2)
    msg.foot3 = not GPIO.input(foot_3)
    msg.foot4 = not GPIO.input(foot_4)
    msg.foot5 = not GPIO.input(foot_5)
    msg.foot6 = not GPIO.input(foot_6)
    
    rospy.loginfo(msg)
    pub.publish(msg)
    r.sleep()

  GPIO.cleanup()

if __name__ == '__main__':
  try:
    pub_leg_state()
  except rospy.ROSInterruptException: pass
